
import React from "react";

import Navbar from "./Navbar";


export default function Header() {
  return <div className="border-b border-gray-800">
    <Navbar />
    
  </div>;
}
